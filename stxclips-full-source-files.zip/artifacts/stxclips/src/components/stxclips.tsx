import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useClerk, useUser } from '@clerk/react';
import {
  ArrowUpRight,
  Check,
  ExternalLink,
  Film,
  Heart,
  History,
  LayoutDashboard,
  Menu,
  Play,
  Search,
  Share2,
  Sparkles,
  Tag,
  X,
} from 'lucide-react';
import { getGetSceneQueryKey, getGetMeQueryKey, getListFavoritesQueryKey, useAddFavorite, useGetMe, useGetScene, useRecordHistory, useRemoveFavorite } from '@workspace/api-client-react';
import type { Scene } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useQueryClient } from '@tanstack/react-query';

export const navItems = [
  { href: '/', label: 'Discover', icon: Sparkles },
  { href: '/search', label: 'Scene search', icon: Search },
  { href: '/anime', label: 'Anime', icon: Film },
  { href: '/characters', label: 'Characters', icon: Tag },
  { href: '/categories', label: 'Categories', icon: LayoutDashboard },
];

export function AppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5" data-testid="link-logo">
      <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground shadow-[0_7px_18px_hsl(183_82%_31%_/_0.22)]">
        <span className="font-display text-lg font-bold tracking-[-.08em]">sx</span>
      </span>
      {!compact && <span className="font-display text-[1.2rem] font-bold tracking-[-.06em]">stxclips</span>}
    </Link>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { isSignedIn } = useUser();
  const { signOut } = useClerk();
  const me = useGetMe({ query: { enabled: Boolean(isSignedIn), queryKey: getGetMeQueryKey() } });
  const initials = me.data?.username?.slice(0, 2).toUpperCase() ?? 'ED';

  return (
    <div className="noise min-h-[100dvh] bg-background">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1500px] items-center justify-between px-5 lg:px-8">
          <AppLogo />
          <div className="hidden items-center gap-1 lg:flex">
            {navItems.slice(0, 3).map(({ href, label }) => (
              <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`rounded-lg px-3 py-2 text-[13px] font-semibold transition-colors ${location === href ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
                {label}
              </Link>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <Link href="/search" data-testid="link-header-search" className="hidden size-9 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground sm:grid"><Search size={17} /></Link>
            {isSignedIn ? (
              <>
                <Link href="/dashboard" data-testid="link-dashboard-header" className="hidden rounded-lg px-3 py-2 text-[13px] font-semibold text-muted-foreground hover:bg-muted hover:text-foreground sm:block">Workspace</Link>
                <button type="button" onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL || '/' })} data-testid="button-sign-out" className="grid size-9 place-items-center rounded-full bg-accent text-[11px] font-bold text-accent-foreground">{initials}</button>
              </>
            ) : (
              <Link href="/sign-in" data-testid="link-sign-in-header" className="rounded-lg border border-border bg-card px-3.5 py-2 text-[13px] font-bold hover:border-primary/50 hover:text-primary">Sign in</Link>
            )}
            <button type="button" onClick={() => setOpen((v) => !v)} aria-label="Open menu" data-testid="button-open-menu" className="grid size-9 place-items-center rounded-lg border border-border lg:hidden"><Menu size={18} /></button>
          </div>
        </div>
        {open && (
          <div className="border-t border-border bg-card px-5 py-3 lg:hidden">
            <div className="flex flex-wrap gap-2">
              {navItems.map(({ href, label }) => <Link key={href} href={href} onClick={() => setOpen(false)} data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`} className="rounded-lg bg-muted px-3 py-2 text-sm font-semibold">{label}</Link>)}
            </div>
          </div>
        )}
      </header>
      <div className="mx-auto flex max-w-[1500px]">
        <aside className="hidden w-[230px] shrink-0 border-r border-border/70 px-5 py-7 lg:block">
          <div className="mb-8 px-2 text-[10px] font-mono-ui font-medium uppercase tracking-[.18em] text-muted-foreground">Editor desk</div>
          <nav className="space-y-1">
            {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-sidebar-${label.toLowerCase().replaceAll(' ', '-')}`} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition ${location === href ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{location === href && <span className="ml-auto size-1.5 rounded-full bg-accent" />}</Link>)}
          </nav>
          <div className="my-8 border-t border-border" />
          <div className="mb-2 px-2 text-[10px] font-mono-ui font-medium uppercase tracking-[.18em] text-muted-foreground">Your library</div>
          <nav className="space-y-1">
            <Link href="/favorites" data-testid="link-sidebar-favorites" className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold ${location === '/favorites' ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}><Heart size={16} strokeWidth={1.8} />Favorites</Link>
            <Link href="/dashboard" data-testid="link-sidebar-workspace" className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold ${location === '/dashboard' ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}><History size={16} strokeWidth={1.8} />Workspace</Link>
          </nav>
          <div className="mt-[34vh] rounded-2xl bg-secondary p-4 text-secondary-foreground">
            <div className="mb-5 flex items-center justify-between"><span className="size-2 rounded-full bg-accent" /><span className="font-mono-ui text-[10px] text-secondary-foreground/60">LIVE INDEX</span></div>
            <p className="font-display text-[15px] font-semibold leading-snug">The fastest path from memory to footage.</p>
            <Link href="/about" data-testid="link-sidebar-about" className="mt-4 flex items-center gap-1 text-xs font-bold text-primary-foreground/70 hover:text-primary-foreground">How it works <ArrowUpRight size={13} /></Link>
          </div>
        </aside>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
      <footer className="mx-auto flex max-w-[1500px] flex-wrap items-center justify-between gap-4 border-t border-border/70 px-5 py-7 text-[11px] text-muted-foreground sm:px-8 lg:px-12">
        <span className="font-mono-ui">STXCLIPS / VISUAL SEARCH DESK</span>
        <div className="flex flex-wrap gap-4">
          <Link href="/faq" data-testid="link-footer-faq" className="hover:text-primary">FAQ</Link>
          <Link href="/help" data-testid="link-footer-help" className="hover:text-primary">Help</Link>
          <Link href="/privacy" data-testid="link-footer-privacy" className="hover:text-primary">Privacy</Link>
          <Link href="/terms" data-testid="link-footer-terms" className="hover:text-primary">Terms</Link>
        </div>
      </footer>
    </div>
  );
}

export function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="mb-9 flex flex-col justify-between gap-5 border-b border-border pb-8 md:flex-row md:items-end">
    <div className="animate-rise">
      <div className="mb-3 flex items-center gap-2 font-mono-ui text-[10px] font-medium uppercase tracking-[.2em] text-primary"><span className="size-1.5 rounded-full bg-accent" />{eyebrow}</div>
      <h1 className="font-display text-4xl font-bold tracking-[-.055em] text-balance sm:text-5xl">{title}</h1>
      {description && <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">{description}</p>}
    </div>
    {action}
  </div>;
}

export function PageFrame({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`px-5 py-9 sm:px-8 lg:px-12 lg:py-12 ${className}`}>{children}</div>;
}

export function ImageWithFallback({ src, alt, className = '' }: { src?: string; alt: string; className?: string }) {
  const [broken, setBroken] = useState(!src);
  return broken ? <div className={`grid place-items-center bg-secondary text-primary ${className}`}><Film size={28} strokeWidth={1.4} /></div> : <img src={src} alt={alt} onError={() => setBroken(true)} className={`object-cover ${className}`} />;
}

export function SceneCard({ scene, onOpen, isFavorite = false, onFavorite }: { scene: Scene; onOpen?: (scene: Scene) => void; isFavorite?: boolean; onFavorite?: (scene: Scene) => void }) {
  const mins = Math.floor(scene.durationSeconds / 60);
  const secs = String(scene.durationSeconds % 60).padStart(2, '0');
  return <article className="group animate-rise overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-card)] transition duration-300 hover:-translate-y-1 hover:border-primary/40" data-testid={`card-scene-${scene.id}`}>
    <button type="button" onClick={() => onOpen?.(scene)} data-testid={`button-open-scene-${scene.id}`} className="relative block aspect-[16/9] w-full overflow-hidden bg-secondary text-left">
      <ImageWithFallback src={scene.thumbnailUrl} alt={scene.title} className="h-full w-full transition duration-500 group-hover:scale-105" />
      <span className="absolute left-3 top-3 rounded-md bg-background/85 px-2 py-1 font-mono-ui text-[10px] text-foreground backdrop-blur">{scene.category}</span>
      <span className="absolute bottom-3 right-3 rounded-md bg-secondary/90 px-2 py-1 font-mono-ui text-[10px] text-secondary-foreground">{mins}:{secs}</span>
      <span className="absolute inset-0 grid place-items-center bg-secondary/35 opacity-0 transition group-hover:opacity-100"><span className="grid size-11 place-items-center rounded-full bg-accent text-accent-foreground"><Play size={17} fill="currentColor" /></span></span>
    </button>
    <div className="p-4">
      <div className="mb-1 flex items-start justify-between gap-3">
        <button type="button" onClick={() => onOpen?.(scene)} data-testid={`button-title-scene-${scene.id}`} className="line-clamp-1 text-left font-display text-[15px] font-bold tracking-[-.02em] hover:text-primary">{scene.title}</button>
        {onFavorite && <button type="button" onClick={() => onFavorite(scene)} data-testid={`button-favorite-scene-${scene.id}`} className={`grid size-7 shrink-0 place-items-center rounded-full transition ${isFavorite ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground hover:text-accent'}`}><Heart size={14} fill={isFavorite ? 'currentColor' : 'none'} /></button>}
      </div>
      <p className="truncate text-xs text-muted-foreground">{scene.animeTitle} <span className="mx-1 text-border">/</span> EP {scene.episode} <span className="mx-1 text-border">/</span> {scene.character}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">{scene.tags.slice(0, 3).map((tag) => <span key={tag} className="rounded bg-muted px-1.5 py-1 font-mono-ui text-[9px] text-muted-foreground">#{tag}</span>)}</div>
    </div>
  </article>;
}

export function SceneSkeletonGrid({ count = 6 }: { count?: number }) {
  return <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{Array.from({ length: count }).map((_, i) => <div key={i} className="overflow-hidden rounded-2xl border border-border bg-card"><div className="skeleton aspect-[16/9]" /><div className="space-y-3 p-4"><div className="skeleton h-4 w-3/4 rounded" /><div className="skeleton h-3 w-1/2 rounded" /><div className="skeleton h-5 w-full rounded" /></div></div>)}</div>;
}

export function QueryError({ onRetry }: { onRetry?: () => void }) {
  return <div className="rounded-2xl border border-accent/30 bg-accent/10 p-8 text-center" data-testid="status-query-error"><div className="mx-auto mb-3 grid size-10 place-items-center rounded-full bg-accent text-accent-foreground"><X size={18} /></div><h3 className="font-display text-lg font-bold">The index blinked</h3><p className="mt-1 text-sm text-muted-foreground">We couldn't reach the scene archive. Try that search again.</p>{onRetry && <Button onClick={onRetry} variant="outline" size="sm" className="mt-5" data-testid="button-retry-query">Retry search</Button>}</div>;
}

export function EmptyState({ title = 'No scenes in this cut yet', description = 'Try a different memory, filter, or character name.' }: { title?: string; description?: string }) {
  return <div className="rounded-2xl border border-dashed border-border bg-card/50 p-14 text-center" data-testid="status-empty"><div className="mx-auto mb-4 grid size-12 place-items-center rounded-2xl bg-muted text-primary"><Search size={20} /></div><h3 className="font-display text-lg font-bold">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">{description}</p></div>;
}

export function SceneDialog({ scene, onClose, isFavorite, onFavorite }: { scene: Scene | null; onClose: () => void; isFavorite?: boolean; onFavorite?: (scene: Scene) => void }) {
  const [shared, setShared] = useState(false);
  const { isSignedIn } = useUser();
  const detail = useGetScene(scene?.id ?? 0, { query: { enabled: Boolean(scene), queryKey: getGetSceneQueryKey(scene?.id ?? 0) } });
  const recordHistory = useRecordHistory();
  useEffect(() => { if (scene?.id && isSignedIn) recordHistory.mutate({ data: { sceneId: scene.id } }); }, [scene?.id, isSignedIn]);
  const activeScene = detail.data ?? scene;
  const mins = activeScene ? Math.floor(activeScene.durationSeconds / 60) : 0;
  const secs = activeScene ? String(activeScene.durationSeconds % 60).padStart(2, '0') : '00';
  return <Dialog open={Boolean(scene)} onOpenChange={(open) => !open && onClose()}><DialogContent className="max-w-3xl overflow-hidden border-border bg-card p-0"><div className="grid md:grid-cols-[1.15fr_.85fr]"><div className="relative aspect-video bg-secondary md:aspect-auto"><ImageWithFallback src={activeScene?.thumbnailUrl} alt={activeScene?.title ?? 'Scene'} className="h-full min-h-[260px] w-full" /><span className="absolute bottom-4 left-4 rounded bg-secondary/90 px-2 py-1 font-mono-ui text-[10px] text-secondary-foreground">{mins}:{secs}</span></div><div className="p-7"><DialogHeader><div className="mb-3 font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">{activeScene?.animeTitle} / episode {activeScene?.episode}</div><DialogTitle className="font-display text-2xl tracking-[-.045em]">{activeScene?.title}</DialogTitle><DialogDescription className="pt-3 text-sm leading-relaxed">{activeScene?.description}</DialogDescription></DialogHeader>{activeScene && <><div className="mt-6 flex flex-wrap gap-1.5">{activeScene.tags.map((tag) => <span key={tag} className="rounded bg-muted px-2 py-1 font-mono-ui text-[10px] text-muted-foreground">#{tag}</span>)}</div><div className="mt-7 flex flex-wrap gap-2"><Button onClick={() => onFavorite?.(activeScene)} data-testid={`button-dialog-favorite-${activeScene.id}`} className="gap-2">{isFavorite ? <Check size={15} /> : <Heart size={15} />} {isFavorite ? 'Saved' : 'Save clip'}</Button><Button onClick={() => { const shareUrl = new URL(window.location.href); shareUrl.searchParams.set('scene', String(activeScene.id)); navigator.clipboard?.writeText(shareUrl.toString()); setShared(true); setTimeout(() => setShared(false), 1500); }} variant="outline" data-testid={`button-dialog-share-${activeScene.id}`}><Share2 size={15} />{shared ? 'Link copied' : 'Share'}</Button></div><a href={activeScene.sourceUrl} target="_blank" rel="noreferrer" data-testid={`link-source-${activeScene.id}`} className="mt-6 flex items-center gap-2 text-xs font-semibold text-muted-foreground hover:text-primary">Open source: {activeScene.sourceName}<ExternalLink size={13} /></a></>}</div></div></DialogContent></Dialog>;
}

export function FavoriteSceneCard({ scene, onOpen }: { scene: Scene; onOpen: (scene: Scene) => void }) {
  const queryClient = useQueryClient();
  const remove = useRemoveFavorite({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() }) } });
  return <SceneCard scene={scene} onOpen={onOpen} isFavorite onFavorite={() => remove.mutate({ sceneId: scene.id })} />;
}

export function useFavoriteActions() {
  const queryClient = useQueryClient();
  const { isSignedIn } = useUser();
  const [notice, setNotice] = useState<string | null>(null);
  const add = useAddFavorite({ mutation: { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() }); setNotice('Clip saved to favorites'); setTimeout(() => setNotice(null), 1800); } } });
  const remove = useRemoveFavorite({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() }) } });
  const favorite = (scene: Scene, isFavorite: boolean) => {
    if (!isSignedIn) {
      setNotice('Sign in to save clips');
      setTimeout(() => setNotice(null), 1800);
      return;
    }
    isFavorite ? remove.mutate({ sceneId: scene.id }) : add.mutate({ sceneId: scene.id });
  };
  return { favorite, notice, isPending: add.isPending || remove.isPending };
}

export function ToastNotice({ message }: { message: string | null }) {
  return message ? <div className="fixed bottom-5 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-full bg-secondary px-4 py-3 text-xs font-semibold text-secondary-foreground shadow-2xl animate-rise" data-testid="status-toast"><Check size={14} className="text-primary" />{message}</div> : null;
}