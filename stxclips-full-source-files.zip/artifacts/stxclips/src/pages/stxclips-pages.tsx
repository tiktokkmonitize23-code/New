import { useMemo, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useUser } from '@clerk/react';
import {
  ArrowRight,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Copy,
  FolderHeart,
  History,
  Search,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import {
  getGetAdminSummaryQueryKey,
  getGetHomeQueryKey,
  getGetMeQueryKey,
  getListAnimeQueryKey,
  getListAdminReportsQueryKey,
  getListAdminScenesQueryKey,
  getListCategoriesQueryKey,
  getListCharactersQueryKey,
  getListFavoritesQueryKey,
  getListHistoryQueryKey,
  getListRecentSourcesQueryKey,
  getListSavedSearchesQueryKey,
  getListScenesQueryKey,
  getListTrendingQueryKey,
  useCreateAdminAnime,
  useCreateAdminCategory,
  useCreateAdminCharacter,
  useCreateAdminScene,
  useCreateSavedSearch,
  useDeleteAdminScene,
  useDeleteSavedSearch,
  useGetAdminSummary,
  useGetHome,
  useGetMe,
  useListAdminReports,
  useListAdminScenes,
  useListAnime,
  useListCategories,
  useListCharacters,
  useListFavorites,
  useListHistory,
  useListRecentSources,
  useListSavedSearches,
  useListScenes,
  useListTrending,
  useUpdateAdminAnime,
  useUpdateAdminCategory,
  useUpdateAdminCharacter,
  useUpdateAdminReport,
  useUpdateAdminScene,
} from '@workspace/api-client-react';
import type { Scene } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PageFrame, PageIntro, SceneCard, SceneDialog, SceneSkeletonGrid, EmptyState, QueryError, FavoriteSceneCard, ToastNotice, useFavoriteActions, ImageWithFallback } from '@/components/stxclips';

function SearchBar({ initial = '', onSubmit, large = false }: { initial?: string; onSubmit: (query: string) => void; large?: boolean }) {
  const [value, setValue] = useState(initial);
  return <form onSubmit={(e) => { e.preventDefault(); onSubmit(value.trim()); }} className={`flex w-full items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-card)] ${large ? 'min-h-[68px] sm:min-h-[78px]' : ''}`}><Search className="ml-3 shrink-0 text-primary" size={large ? 22 : 18} /><input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Remember a moment? Search by feeling, line, or character..." data-testid="input-scene-search" className={`min-w-0 flex-1 bg-transparent px-2 outline-none placeholder:text-muted-foreground ${large ? 'text-sm sm:text-base' : 'text-sm'}`} /><kbd className="hidden rounded-md bg-muted px-2 py-1 font-mono-ui text-[10px] text-muted-foreground sm:block">⌘ K</kbd><Button type="submit" size={large ? 'default' : 'sm'} data-testid="button-submit-search">{large ? 'Find the cut' : 'Search'}</Button></form>;
}

function SectionHeading({ eyebrow, title, href, linkLabel = 'See all' }: { eyebrow: string; title: string; href?: string; linkLabel?: string }) {
  return <div className="mb-5 flex items-end justify-between gap-4"><div><div className="mb-2 font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">{eyebrow}</div><h2 className="font-display text-2xl font-bold tracking-[-.045em]">{title}</h2></div>{href && <Link href={href} data-testid={`link-see-${href.slice(1)}`} className="flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-primary">{linkLabel}<ArrowRight size={14} /></Link>}</div>;
}

function HomePage() {
  const [, setLocation] = useLocation();
  const home = useGetHome({ query: { queryKey: getGetHomeQueryKey() } });
  const trending = useListTrending({ query: { queryKey: getListTrendingQueryKey() } });
  const recent = useListRecentSources({ query: { queryKey: getListRecentSourcesQueryKey() } });
  const [selected, setSelected] = useState<Scene | null>(null);
  const { favorite, notice } = useFavoriteActions();
  const [favorites, setFavorites] = useState<number[]>([]);
  const data = home.data;
  if (home.isLoading) return <PageFrame><div className="mb-10 h-[290px] skeleton rounded-[28px]" /><SceneSkeletonGrid count={6} /></PageFrame>;
  if (home.isError || !data) return <PageFrame><QueryError onRetry={() => home.refetch()} /></PageFrame>;
  const featured = data.featuredScenes ?? [];
  const main = featured[0];
  return <PageFrame className="space-y-14">
    <section className="relative overflow-hidden rounded-[28px] bg-secondary px-6 py-10 text-secondary-foreground sm:px-12 sm:py-14 lg:px-16 lg:py-16">
      <div className="absolute -right-12 -top-24 size-80 rounded-full border-[38px] border-primary/20" /><div className="absolute -bottom-36 right-32 size-72 rounded-full border-[1px] border-accent/40" />
      <div className="relative max-w-3xl animate-rise"><div className="mb-5 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary"><span className="size-1.5 rounded-full bg-accent" />Visual search for editors</div><h1 className="font-display text-5xl font-bold leading-[.95] tracking-[-.075em] sm:text-7xl lg:text-[6.8rem]">Find the<br /><span className="text-primary">exact feeling.</span></h1><p className="mt-7 max-w-lg text-sm leading-relaxed text-secondary-foreground/70 sm:text-base">Stxclips turns half-remembered anime moments into usable footage. Search the pause, the impact, the look — then get back to your timeline.</p><div className="mt-8 max-w-2xl"><SearchBar large onSubmit={(query) => setLocation(`/search?q=${encodeURIComponent(query)}`)} /></div><div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] text-secondary-foreground/55"><span>Try:</span>{(trending.data ?? data.trending).slice(0, 3).map((item) => <button type="button" key={item.term} onClick={() => setLocation(`/search?q=${encodeURIComponent(item.term)}`)} data-testid={`button-trending-${item.term}`} className="border-b border-secondary-foreground/20 pb-0.5 hover:border-primary hover:text-primary">{item.term}</button>)}</div></div>
    </section>
    <section><SectionHeading eyebrow="Curated cuts" title="Scenes worth keeping open" href="/search" /><div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{featured.slice(0, 6).map((scene, i) => <div key={scene.id} className={i === 0 ? 'sm:col-span-2 xl:col-span-1' : ''}><SceneCard scene={scene} onOpen={setSelected} isFavorite={favorites.includes(scene.id)} onFavorite={(s) => { setFavorites((old) => old.includes(s.id) ? old.filter((id) => id !== s.id) : [...old, s.id]); favorite(s, favorites.includes(s.id)); }} /></div>)}</div></section>
    <section className="grid gap-8 lg:grid-cols-[1.3fr_.7fr]"><div><SectionHeading eyebrow="The index is moving" title="What editors are reaching for" href="/anime" /><div className="grid gap-3 sm:grid-cols-2">{data.popularAnime.slice(0, 4).map((anime) => <Link href={`/search?anime=${anime.slug}`} key={anime.id} data-testid={`card-anime-${anime.id}`} className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-3 transition hover:-translate-y-0.5 hover:border-primary/40"><ImageWithFallback src={anime.imageUrl} alt={anime.title} className="size-16 shrink-0 rounded-xl" /><span className="min-w-0"><strong className="block truncate font-display text-sm">{anime.title}</strong><span className="mt-1 block font-mono-ui text-[10px] text-muted-foreground">{anime.genre} / {anime.sceneCount} scenes</span></span><ArrowRight size={15} className="ml-auto text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" /></Link>)}</div></div><div><SectionHeading eyebrow="Right now" title="Trending memory" /><div className="divide-y divide-border rounded-2xl border border-border bg-card px-5">{(trending.data ?? data.trending).slice(0, 5).map((item, i) => <button type="button" key={item.term} onClick={() => setLocation(`/search?q=${encodeURIComponent(item.term)}`)} data-testid={`button-trend-row-${i}`} className="flex w-full items-center gap-3 py-4 text-left hover:text-primary"><span className="w-5 font-mono-ui text-[10px] text-muted-foreground">0{i + 1}</span><span className="flex-1 text-sm font-semibold">{item.term}</span><span className={`font-mono-ui text-[10px] ${item.trend === 'up' ? 'text-primary' : 'text-muted-foreground'}`}>{item.trend === 'new' ? 'NEW' : `${item.count} uses`}</span></button>)}</div></div></section>
    <section><SectionHeading eyebrow="Fresh from the archive" title="Recently indexed sources" href="/search" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{(recent.data ?? data.recentSources).slice(0, 4).map((scene) => <button type="button" onClick={() => setSelected(scene)} key={scene.id} data-testid={`card-recent-source-${scene.id}`} className="group relative overflow-hidden rounded-2xl bg-secondary text-left"><ImageWithFallback src={scene.thumbnailUrl} alt={scene.title} className="aspect-[4/3] w-full opacity-80 transition group-hover:scale-105 group-hover:opacity-100" /><div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-secondary via-secondary/80 to-transparent p-4 pt-12 text-secondary-foreground"><div className="truncate font-display text-sm font-bold">{scene.title}</div><div className="mt-1 text-[10px] text-secondary-foreground/60">{scene.sourceName}</div></div></button>)}</div></section>
    <SceneDialog scene={selected} onClose={() => setSelected(null)} /><ToastNotice message={notice} />
  </PageFrame>;
}

function SearchPage() {
  const params = new URLSearchParams(window.location.search);
  const [query, setQuery] = useState(params.get('q') ?? '');
  const [filters, setFilters] = useState({ anime: params.get('anime') ?? '', character: '', category: '', durationMax: '' });
  const [page, setPage] = useState(1);
  const apiParams = useMemo(() => ({ q: query || undefined, anime: filters.anime || undefined, character: filters.character || undefined, category: filters.category || undefined, durationMax: filters.durationMax ? Number(filters.durationMax) : undefined, page, pageSize: 12 }), [query, filters, page]);
  const scenes = useListScenes(apiParams, { query: { queryKey: getListScenesQueryKey(apiParams) } });
  const anime = useListAnime({ query: { queryKey: getListAnimeQueryKey() } });
  const chars = useListCharacters({ query: { queryKey: getListCharactersQueryKey() } });
  const categories = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const [selected, setSelected] = useState<Scene | null>(null);
  const { favorite, notice } = useFavoriteActions();
  const [favorites, setFavorites] = useState<number[]>([]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const submit = (q: string) => { setQuery(q); setPage(1); };
  return <PageFrame><PageIntro eyebrow="Scene search" title="Search the moment." description="Describe what you remember. The archive is indexed for the details editors actually notice." /><div className="mb-7 max-w-3xl"><SearchBar initial={query} onSubmit={submit} /></div><div className="mb-7 flex flex-wrap items-center gap-2"><button type="button" onClick={() => setFiltersOpen((v) => !v)} data-testid="button-toggle-filters" className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-bold ${filtersOpen ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-card'}`}><SlidersHorizontal size={14} /> Filters</button>{query && <button type="button" onClick={() => submit('')} data-testid="button-clear-search" className="rounded-lg bg-muted px-3 py-2 text-xs font-semibold">Clear query</button>}<span className="ml-auto font-mono-ui text-[10px] text-muted-foreground">{scenes.data?.total ?? 0} scenes indexed</span></div>{filtersOpen && <div className="mb-8 grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-2 lg:grid-cols-4"><label className="text-xs font-bold">Anime<select value={filters.anime} onChange={(e) => { setFilters({ ...filters, anime: e.target.value }); setPage(1); }} data-testid="select-filter-anime" className="mt-2 w-full rounded-lg border border-border bg-background p-2.5 text-sm font-normal outline-none"><option value="">Any anime</option>{(anime.data ?? []).map((a) => <option key={a.id} value={a.slug}>{a.title}</option>)}</select></label><label className="text-xs font-bold">Character<select value={filters.character} onChange={(e) => { setFilters({ ...filters, character: e.target.value }); setPage(1); }} data-testid="select-filter-character" className="mt-2 w-full rounded-lg border border-border bg-background p-2.5 text-sm font-normal outline-none"><option value="">Any character</option>{(chars.data ?? []).map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}</select></label><label className="text-xs font-bold">Category<select value={filters.category} onChange={(e) => { setFilters({ ...filters, category: e.target.value }); setPage(1); }} data-testid="select-filter-category" className="mt-2 w-full rounded-lg border border-border bg-background p-2.5 text-sm font-normal outline-none"><option value="">Any category</option>{(categories.data ?? []).map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}</select></label><label className="text-xs font-bold">Under duration<select value={filters.durationMax} onChange={(e) => { setFilters({ ...filters, durationMax: e.target.value }); setPage(1); }} data-testid="select-filter-duration" className="mt-2 w-full rounded-lg border border-border bg-background p-2.5 text-sm font-normal outline-none"><option value="">Any length</option><option value="10">10 seconds</option><option value="30">30 seconds</option><option value="60">1 minute</option></select></label></div>}{scenes.isLoading ? <SceneSkeletonGrid /> : scenes.isError ? <QueryError onRetry={() => scenes.refetch()} /> : scenes.data?.items.length ? <><div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{scenes.data.items.map((scene) => <SceneCard key={scene.id} scene={scene} onOpen={setSelected} isFavorite={favorites.includes(scene.id)} onFavorite={(s) => { setFavorites((old) => old.includes(s.id) ? old.filter((id) => id !== s.id) : [...old, s.id]); favorite(s, favorites.includes(s.id)); }} />)}</div><div className="mt-9 flex items-center justify-center gap-3"><Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((v) => Math.max(1, v - 1))} data-testid="button-previous-page"><ChevronLeft size={14} />Previous</Button><span className="rounded-lg bg-muted px-3 py-2 font-mono-ui text-[10px]">PAGE {page}</span><Button variant="outline" size="sm" disabled={(scenes.data.total ?? 0) <= page * 12} onClick={() => setPage((v) => v + 1)} data-testid="button-next-page">Next<ChevronRight size={14} /></Button></div></> : <EmptyState title={query ? `Nothing matched “${query}”` : 'The archive is waiting'} /> }<SceneDialog scene={selected} onClose={() => setSelected(null)} /><ToastNotice message={notice} /></PageFrame>;
}

function BrowsePage({ type }: { type: 'anime' | 'characters' | 'categories' }) {
  const anime = useListAnime({ query: { queryKey: getListAnimeQueryKey() } });
  const characters = useListCharacters({ query: { queryKey: getListCharactersQueryKey() } });
  const categories = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const list = type === 'anime' ? anime.data : type === 'characters' ? characters.data : categories.data;
  const loading = type === 'anime' ? anime.isLoading : type === 'characters' ? characters.isLoading : categories.isLoading;
  const title = type === 'anime' ? 'Browse anime.' : type === 'characters' ? 'Browse characters.' : 'Browse by feeling.';
  const eyebrow = type === 'anime' ? 'Worlds in the index' : type === 'characters' ? 'Faces editors remember' : 'Scene taxonomy';
  return <PageFrame><PageIntro eyebrow={eyebrow} title={title} description={type === 'categories' ? 'Search less by title. Start with the emotional temperature of the cut.' : 'A living index of the shows, faces, and worlds behind the scenes.'} />{loading ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 9 }).map((_, i) => <div key={i} className="skeleton h-28 rounded-2xl" />)}</div> : type === 'anime' ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{(list ?? []).map((item) => { const a = item as NonNullable<typeof anime.data>[number]; return <Link href={`/search?anime=${a.slug}`} key={a.id} data-testid={`card-browse-anime-${a.id}`} className="group flex gap-4 rounded-2xl border border-border bg-card p-3 transition hover:-translate-y-1 hover:border-primary/40"><ImageWithFallback src={a.imageUrl} alt={a.title} className="size-24 shrink-0 rounded-xl" /><div className="min-w-0 py-1"><div className="font-mono-ui text-[10px] text-primary">{a.year} / {a.genre}</div><h3 className="mt-2 truncate font-display text-lg font-bold">{a.title}</h3><p className="mt-2 text-xs text-muted-foreground">{a.sceneCount} indexed scenes</p></div><ArrowRight className="ml-auto mt-2 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" size={16} /></Link>; })}</div> : type === 'characters' ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{(list ?? []).map((item) => { const c = item as NonNullable<typeof characters.data>[number]; return <Link href={`/search?character=${encodeURIComponent(c.name)}`} key={c.id} data-testid={`card-browse-character-${c.id}`} className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition hover:-translate-y-1 hover:border-primary/40"><ImageWithFallback src={c.imageUrl} alt={c.name} className="size-16 rounded-full" /><div className="min-w-0"><h3 className="truncate font-display text-base font-bold">{c.name}</h3><p className="mt-1 truncate text-xs text-muted-foreground">{c.animeTitle} / {c.role}</p><p className="mt-2 font-mono-ui text-[10px] text-primary">{c.sceneCount} scenes</p></div><ArrowRight className="ml-auto text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" size={16} /></Link>; })}</div> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{(list ?? []).map((item) => { const c = item as NonNullable<typeof categories.data>[number]; return <Link href={`/search?category=${c.slug}`} key={c.id} data-testid={`card-browse-category-${c.id}`} className="group rounded-2xl border border-border bg-card p-6 transition hover:-translate-y-1 hover:border-primary/40"><div className="mb-8 flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-primary/10 text-primary"><Sparkles size={17} /></span><ArrowRight className="text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" size={16} /></div><h3 className="font-display text-xl font-bold">{c.name}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.description}</p><div className="mt-5 font-mono-ui text-[10px] text-primary">{c.sceneCount} scenes indexed</div></Link>; })}</div>}</PageFrame>;
}

function FavoritesPage() {
  const { isSignedIn } = useUser();
  const [, setLocation] = useLocation();
  const favorites = useListFavorites({ query: { enabled: Boolean(isSignedIn), queryKey: getListFavoritesQueryKey() } });
  const [selected, setSelected] = useState<Scene | null>(null);
  if (!isSignedIn) return <PageFrame><AuthPrompt title="Your best cuts belong here." description="Sign in to keep a private shelf of scenes you know you'll use again." /></PageFrame>;
  return <PageFrame><PageIntro eyebrow="Your library" title="Favorites." description="A quick shelf for the scenes that survived the first pass." action={<Link href="/search" data-testid="link-find-more-favorites" className="flex items-center gap-2 rounded-lg bg-secondary px-4 py-2.5 text-xs font-bold text-secondary-foreground">Find more <Search size={14} /></Link>} />{favorites.isLoading ? <SceneSkeletonGrid count={4} /> : favorites.isError ? <QueryError onRetry={() => favorites.refetch()} /> : favorites.data?.length ? <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{favorites.data.map((scene) => <FavoriteSceneCard key={scene.id} scene={scene} onOpen={setSelected} />)}</div> : <EmptyState title="Your shelf is empty" description="When a scene feels right, save it here for the next edit." />}<SceneDialog scene={selected} onClose={() => setSelected(null)} /><button type="button" onClick={() => setLocation('/search')} data-testid="button-empty-find-scenes" className="sr-only">Find scenes</button></PageFrame>;
}

function AuthPrompt({ title, description }: { title: string; description: string }) {
  return <div className="mx-auto max-w-lg rounded-[28px] border border-border bg-card p-9 text-center shadow-[var(--shadow-card)]"><div className="mx-auto mb-5 grid size-14 place-items-center rounded-2xl bg-secondary text-primary"><FolderHeart size={24} /></div><h2 className="font-display text-2xl font-bold tracking-[-.05em]">{title}</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{description}</p><div className="mt-7 flex justify-center gap-2"><Link href="/sign-in" data-testid="link-auth-prompt-sign-in" className="rounded-lg bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground">Sign in</Link><Link href="/sign-up" data-testid="link-auth-prompt-sign-up" className="rounded-lg border border-border px-4 py-2.5 text-xs font-bold">Create account</Link></div></div>;
}

function DashboardPage() {
  const { isSignedIn } = useUser();
  const me = useGetMe({ query: { enabled: Boolean(isSignedIn), queryKey: getGetMeQueryKey() } });
  const searches = useListSavedSearches({ query: { enabled: Boolean(isSignedIn), queryKey: getListSavedSearchesQueryKey() } });
  const history = useListHistory({ query: { enabled: Boolean(isSignedIn), queryKey: getListHistoryQueryKey() } });
  const create = useCreateSavedSearch();
  const remove = useDeleteSavedSearch();
  const client = useQueryClient();
  const [name, setName] = useState('');
  const [query, setQuery] = useState('');
  const [copied, setCopied] = useState<number | null>(null);
  if (!isSignedIn) return <PageFrame><AuthPrompt title="A workspace for the long cut." description="Save searches, revisit your history, and build a personal visual index beside your timeline." /></PageFrame>;
  const saveSearch = () => { if (!name.trim() || !query.trim()) return; create.mutate({ data: { name: name.trim(), query: query.trim() } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListSavedSearchesQueryKey() }); setName(''); setQuery(''); } }); };
  return <PageFrame><PageIntro eyebrow="Editor workspace" title={`Good to see you${me.data?.username ? `, ${me.data.username}` : ''}.`} description="Your shortcuts into the Stxclips archive." /><div className="grid gap-5 lg:grid-cols-[1.25fr_.75fr]"><section className="rounded-2xl border border-border bg-card p-6"><div className="mb-6 flex items-center justify-between"><div><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">Saved searches</div><h2 className="mt-2 font-display text-xl font-bold">Your recurring instincts</h2></div><Bookmark className="text-primary" size={20} /></div><div className="mb-5 grid gap-2 sm:grid-cols-[1fr_1fr_auto]"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name this search" data-testid="input-saved-search-name" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. rain + quiet rage" data-testid="input-saved-search-query" /><Button onClick={saveSearch} disabled={create.isPending} data-testid="button-create-saved-search">Save</Button></div><div className="divide-y divide-border">{searches.isLoading ? <><div className="skeleton h-12" /><div className="skeleton mt-2 h-12" /></> : searches.data?.length ? searches.data.map((item) => <div key={item.id} className="flex items-center gap-3 py-3"><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{item.name}</div><div className="truncate font-mono-ui text-[10px] text-muted-foreground">{item.query}</div></div><button type="button" onClick={() => { navigator.clipboard?.writeText(item.query); setCopied(item.id); setTimeout(() => setCopied(null), 1300); }} data-testid={`button-copy-search-${item.id}`} className="grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-primary">{copied === item.id ? <span className="text-[10px] text-primary">OK</span> : <Copy size={14} />}</button><button type="button" onClick={() => remove.mutate({ searchId: item.id }, { onSuccess: () => client.invalidateQueries({ queryKey: getListSavedSearchesQueryKey() }) })} data-testid={`button-delete-search-${item.id}`} className="grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-accent/15 hover:text-accent">×</button></div>) : <p className="py-8 text-center text-sm text-muted-foreground">No saved searches yet. Name the search you reach for every week.</p>}</div></section><section className="rounded-2xl border border-border bg-secondary p-6 text-secondary-foreground"><div className="mb-6 flex items-center justify-between"><div><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">Recent history</div><h2 className="mt-2 font-display text-xl font-bold">Last seen</h2></div><History className="text-primary" size={20} /></div><div className="space-y-3">{history.isLoading ? <div className="skeleton h-40 rounded-xl" /> : history.data?.length ? history.data.slice(0, 5).map((scene) => <Link href={`/search?q=${encodeURIComponent(scene.title)}`} key={scene.id} data-testid={`link-history-scene-${scene.id}`} className="group flex items-center gap-3 rounded-xl bg-secondary-foreground/5 p-2 hover:bg-secondary-foreground/10"><ImageWithFallback src={scene.thumbnailUrl} alt={scene.title} className="size-12 rounded-lg" /><span className="min-w-0 flex-1 truncate text-xs font-semibold">{scene.title}</span><ArrowRight size={14} className="text-secondary-foreground/40 transition group-hover:translate-x-1 group-hover:text-primary" /></Link>) : <p className="text-sm text-secondary-foreground/60">Open a scene and it will appear here.</p>}</div></section></div></PageFrame>;
}

function LegacyAdminPage() {
  const { isSignedIn } = useUser();
  const admin = useGetAdminSummary({ query: { enabled: Boolean(isSignedIn), queryKey: getGetAdminSummaryQueryKey() } });
  if (!isSignedIn) return <PageFrame><AuthPrompt title="This desk is private." description="Sign in with an admin account to view archive health and source flags." /></PageFrame>;
  return <PageFrame><PageIntro eyebrow="Admin / index health" title="Archive overview." description="A quiet read on the collection behind the editor desk." />{admin.isLoading ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="skeleton h-32 rounded-2xl" />)}</div> : admin.isError ? <QueryError onRetry={() => admin.refetch()} /> : <><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{[['Scenes', admin.data?.sceneCount, 'sceneCount'], ['Anime', admin.data?.animeCount, 'animeCount'], ['Characters', admin.data?.characterCount, 'characterCount'], ['Categories', admin.data?.categoryCount, 'categoryCount'], ['Flagged sources', admin.data?.flaggedSourceCount, 'flaggedSourceCount']].map(([label, value, key], i) => <div key={key} data-testid={`stat-admin-${key}`} className={`rounded-2xl border border-border p-5 ${i === 4 ? 'bg-accent/10' : 'bg-card'}`}><div className="font-mono-ui text-[10px] uppercase tracking-[.15em] text-muted-foreground">{label}</div><div className="mt-5 font-display text-4xl font-bold tracking-[-.06em]">{value ?? '—'}</div></div>)}</div><div className="mt-8 rounded-2xl border border-border bg-card p-6"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-xl bg-primary/10 text-primary"><TrendingUp size={17} /></span><div><h2 className="font-display text-lg font-bold">Index is operational</h2><p className="text-sm text-muted-foreground">Scene search is ready for the next cut.</p></div></div></div></>}</PageFrame>;
}

function SceneCatalogForm({ onNotice }: { onNotice: (message: string) => void }) {
  const client = useQueryClient();
  const create = useCreateAdminScene();
  const [draft, setDraft] = useState({
    title: '', animeTitle: '', animeSlug: '', character: '', episode: '1', description: '',
    thumbnailUrl: '', durationSeconds: '10', sourceName: '', sourceUrl: '', tags: '', category: '', isFeatured: false,
  });
  const update = (key: keyof typeof draft, value: string | boolean) => setDraft((current) => ({ ...current, [key]: value }));
  const submit = () => {
    if (!draft.title.trim() || !draft.animeTitle.trim() || !draft.animeSlug.trim() || !draft.character.trim() || !draft.description.trim() || !draft.sourceName.trim() || !draft.sourceUrl.trim() || !draft.category.trim()) {
      onNotice('Add the required scene details before publishing it to the index.');
      return;
    }
    create.mutate({ data: {
      title: draft.title.trim(), animeTitle: draft.animeTitle.trim(), animeSlug: draft.animeSlug.trim(),
      character: draft.character.trim(), episode: Number(draft.episode), description: draft.description.trim(),
      thumbnailUrl: draft.thumbnailUrl.trim(), durationSeconds: Number(draft.durationSeconds),
      sourceName: draft.sourceName.trim(), sourceUrl: draft.sourceUrl.trim(),
      tags: draft.tags.split(',').map((tag) => tag.trim()).filter(Boolean).slice(0, 12),
      category: draft.category.trim(), isFeatured: draft.isFeatured,
    } }, {
      onSuccess: () => {
        client.invalidateQueries({ queryKey: getListAdminScenesQueryKey() });
        client.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
        client.invalidateQueries({ queryKey: getGetHomeQueryKey() });
        client.invalidateQueries({ queryKey: getListScenesQueryKey() });
        setDraft({ title: '', animeTitle: '', animeSlug: '', character: '', episode: '1', description: '', thumbnailUrl: '', durationSeconds: '10', sourceName: '', sourceUrl: '', tags: '', category: '', isFeatured: false });
        onNotice('Scene added to the archive.');
      },
      onError: () => onNotice('The scene could not be added. Check the fields and try again.'),
    });
  };
  const field = (key: keyof typeof draft, label: string, placeholder: string, type = 'text') => <label className="text-[11px] font-bold text-foreground">{label}<Input type={type} value={String(draft[key])} onChange={(event) => update(key, event.target.value)} placeholder={placeholder} data-testid={`input-admin-scene-${String(key)}`} className="mt-1.5 h-9 text-xs" /></label>;
  return <section className="rounded-2xl border border-border bg-card p-5 sm:p-6">
    <div className="mb-5 flex items-start justify-between gap-4"><div><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">Catalog editor</div><h2 className="mt-2 font-display text-xl font-bold">Add a scene</h2><p className="mt-1 text-xs text-muted-foreground">Every field is written directly to the protected archive.</p></div><span className="rounded-lg bg-primary/10 px-2 py-1 font-mono-ui text-[9px] text-primary">SCENE INPUT</span></div>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{field('title', 'Title *', 'A quiet arrival')}{field('animeTitle', 'Anime title *', 'Series title')}{field('animeSlug', 'Anime slug *', 'series-title')}{field('character', 'Character *', 'Character name')}{field('episode', 'Episode *', '12', 'number')}{field('category', 'Category *', 'quiet, impact, reveal')}{field('thumbnailUrl', 'Thumbnail URL', 'https://...')}{field('durationSeconds', 'Duration seconds *', '24', 'number')}{field('sourceName', 'Source name *', 'Publisher or channel')}{field('sourceUrl', 'Source URL *', 'https://...')}{field('tags', 'Tags', 'rain, close-up, resolve')}</div>
    <label className="mt-3 block text-[11px] font-bold">Description *<textarea value={draft.description} onChange={(event) => update('description', event.target.value)} placeholder="What does the editor remember about this moment?" data-testid="input-admin-scene-description" className="mt-1.5 min-h-20 w-full resize-y rounded-md border border-input bg-background px-3 py-2 text-xs outline-none ring-offset-background placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-ring" /></label>
    <div className="mt-4 flex flex-wrap items-center justify-between gap-4"><label className="flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={draft.isFeatured} onChange={(event) => update('isFeatured', event.target.checked)} data-testid="input-admin-scene-featured" className="size-4 accent-[hsl(var(--primary))]" /> Feature this scene in discovery</label><Button onClick={submit} disabled={create.isPending} data-testid="button-create-admin-scene">{create.isPending ? 'Adding…' : 'Add scene to index'}</Button></div>
  </section>;
}

function AdminMetaCard({ kind }: { kind: 'anime' | 'character' | 'category' }) {
  const client = useQueryClient();
  const createAnime = useCreateAdminAnime();
  const updateAnime = useUpdateAdminAnime();
  const createCharacter = useCreateAdminCharacter();
  const updateCharacter = useUpdateAdminCharacter();
  const createCategory = useCreateAdminCategory();
  const updateCategory = useUpdateAdminCategory();
  const [id, setId] = useState('');
  const [form, setForm] = useState<Record<string, string>>({ title: '', slug: '', year: '', genre: '', accent: '', imageUrl: '', sceneCount: '0', name: '', animeTitle: '', role: '', description: '' });
  const set = (key: string, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const label = kind === 'anime' ? 'Anime metadata' : kind === 'character' ? 'Character metadata' : 'Category metadata';
  const submit = () => {
    if (kind === 'anime') {
      const data = { title: form.title.trim(), slug: form.slug.trim(), year: Number(form.year), genre: form.genre.trim(), accent: form.accent.trim(), imageUrl: form.imageUrl.trim(), sceneCount: Number(form.sceneCount) };
      const done = () => { client.invalidateQueries({ queryKey: getListAnimeQueryKey() }); client.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); setForm({ title: '', slug: '', year: '', genre: '', accent: '', imageUrl: '', sceneCount: '0', name: '', animeTitle: '', role: '', description: '' }); setId(''); };
      if (id) updateAnime.mutate({ animeId: Number(id), data }, { onSuccess: done }); else createAnime.mutate({ data }, { onSuccess: done });
    } else if (kind === 'character') {
      const data = { name: form.name.trim(), animeTitle: form.animeTitle.trim(), role: form.role.trim(), imageUrl: form.imageUrl.trim(), sceneCount: Number(form.sceneCount) };
      const done = () => { client.invalidateQueries({ queryKey: getListCharactersQueryKey() }); client.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); setForm({ title: '', slug: '', year: '', genre: '', accent: '', imageUrl: '', sceneCount: '0', name: '', animeTitle: '', role: '', description: '' }); setId(''); };
      if (id) updateCharacter.mutate({ characterId: Number(id), data }, { onSuccess: done }); else createCharacter.mutate({ data }, { onSuccess: done });
    } else {
      const data = { name: form.name.trim(), slug: form.slug.trim(), sceneCount: Number(form.sceneCount), description: form.description.trim() };
      const done = () => { client.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); client.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); setForm({ title: '', slug: '', year: '', genre: '', accent: '', imageUrl: '', sceneCount: '0', name: '', animeTitle: '', role: '', description: '' }); setId(''); };
      if (id) updateCategory.mutate({ categoryId: Number(id), data }, { onSuccess: done }); else createCategory.mutate({ data }, { onSuccess: done });
    }
  };
  const busy = createAnime.isPending || updateAnime.isPending || createCharacter.isPending || updateCharacter.isPending || createCategory.isPending || updateCategory.isPending;
  const input = (key: string, text: string, placeholder: string, type = 'text') => <label className="text-[10px] font-bold">{text}<Input type={type} value={form[key] ?? ''} onChange={(event) => set(key, event.target.value)} placeholder={placeholder} data-testid={`input-admin-${kind}-${key}`} className="mt-1 h-8 text-[11px]" /></label>;
  return <div className="rounded-2xl border border-border bg-card p-4"><div className="mb-3 flex items-center justify-between"><h3 className="font-display text-sm font-bold">{label}</h3><span className="font-mono-ui text-[9px] text-muted-foreground">CREATE / UPDATE</span></div><div className="mb-2">{input('id', 'Existing ID (optional)', 'Leave empty to create', 'number')}</div>{kind === 'anime' && <div className="grid gap-2 sm:grid-cols-2">{input('title', 'Title *', 'Series title')}{input('slug', 'Slug *', 'series-title')}{input('year', 'Year *', '2024', 'number')}{input('genre', 'Genre *', 'Action')}{input('accent', 'Accent *', '#087d7e')}{input('imageUrl', 'Image URL', 'https://...')}{input('sceneCount', 'Scene count', '0', 'number')}</div>}{kind === 'character' && <div className="grid gap-2 sm:grid-cols-2">{input('name', 'Name *', 'Character')}{input('animeTitle', 'Anime title *', 'Series')}{input('role', 'Role *', 'Rival')}{input('imageUrl', 'Image URL', 'https://...')}{input('sceneCount', 'Scene count', '0', 'number')}</div>}{kind === 'category' && <div className="grid gap-2 sm:grid-cols-2">{input('name', 'Name *', 'Quiet')}{input('slug', 'Slug *', 'quiet')}{input('sceneCount', 'Scene count', '0', 'number')}<label className="text-[10px] font-bold">Description *<Input value={form.description} onChange={(event) => set('description', event.target.value)} placeholder="Short editorial descriptor" data-testid="input-admin-category-description" className="mt-1 h-8 text-[11px]" /></label></div>}<Button onClick={submit} disabled={busy} variant="outline" size="sm" className="mt-3 w-full" data-testid={`button-save-admin-${kind}`}>{busy ? 'Saving…' : id ? `Update ${kind}` : `Create ${kind}`}</Button></div>;
}

function AdminPage() {
  const { isSignedIn } = useUser();
  const admin = useGetAdminSummary({ query: { enabled: Boolean(isSignedIn), queryKey: getGetAdminSummaryQueryKey() } });
  const scenes = useListAdminScenes({ query: { enabled: admin.isSuccess, queryKey: getListAdminScenesQueryKey() } });
  const reports = useListAdminReports({ query: { enabled: admin.isSuccess, queryKey: getListAdminReportsQueryKey() } });
  const updateScene = useUpdateAdminScene();
  const deleteScene = useDeleteAdminScene();
  const updateReport = useUpdateAdminReport();
  const client = useQueryClient();
  const [notice, setNotice] = useState<string | null>(null);
  const announce = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(null), 2200); };
  const refreshScenes = () => { client.invalidateQueries({ queryKey: getListAdminScenesQueryKey() }); client.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); client.invalidateQueries({ queryKey: getGetHomeQueryKey() }); client.invalidateQueries({ queryKey: getListScenesQueryKey() }); };
  const scenePayload = (scene: Scene, isFeatured: boolean) => ({ title: scene.title, animeTitle: scene.animeTitle, animeSlug: scene.animeSlug, character: scene.character, episode: scene.episode, description: scene.description, thumbnailUrl: scene.thumbnailUrl, durationSeconds: scene.durationSeconds, sourceName: scene.sourceName, sourceUrl: scene.sourceUrl, tags: scene.tags, category: scene.category, isFeatured });
  if (!isSignedIn) return <PageFrame><AuthPrompt title="This desk is private." description="Sign in with an admin account to view archive health and source flags." /></PageFrame>;
  if (admin.isLoading) return <PageFrame><PageIntro eyebrow="Admin / index health" title="Opening the archive." /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="skeleton h-32 rounded-2xl" />)}</div></PageFrame>;
  if (admin.isError || !admin.data) { const status = (admin.error as { status?: number } | null)?.status; return <PageFrame><div className="rounded-2xl border border-accent/35 bg-accent/10 p-10 text-center" data-testid="status-admin-error"><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-accent">{status === 403 ? '403 / ADMIN ACCESS REQUIRED' : 'ADMIN REQUEST FAILED'}</div><h1 className="mt-3 font-display text-2xl font-bold">{status === 403 ? 'This desk is restricted.' : 'The admin index is unavailable.'}</h1><p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">{status === 403 ? 'Your account does not have permission to manage the Stxclips catalog.' : 'We could not load the protected archive summary. Try again when the API is available.'}</p><Button onClick={() => admin.refetch()} variant="outline" size="sm" className="mt-6" data-testid="button-retry-admin-summary">Retry</Button></div></PageFrame>; }
  const summary = admin.data;
  return <PageFrame><PageIntro eyebrow="Admin / index health" title="Archive overview." description="Manage the collection behind the editor desk without leaving the visual language of the archive." /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{[['Scenes', summary.sceneCount, 'sceneCount'], ['Anime', summary.animeCount, 'animeCount'], ['Characters', summary.characterCount, 'characterCount'], ['Categories', summary.categoryCount, 'categoryCount'], ['Flagged sources', summary.flaggedSourceCount, 'flaggedSourceCount']].map(([label, value, key], i) => <div key={key} data-testid={`stat-admin-${key}`} className={`rounded-2xl border border-border p-5 ${i === 4 ? 'bg-accent/10' : 'bg-card'}`}><div className="font-mono-ui text-[10px] uppercase tracking-[.15em] text-muted-foreground">{label}</div><div className="mt-5 font-display text-4xl font-bold tracking-[-.06em]">{value}</div></div>)}</div><div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_.8fr]"><SceneCatalogForm onNotice={announce} /><section className="rounded-2xl border border-border bg-secondary p-5 text-secondary-foreground"><div className="mb-5 flex items-center justify-between"><div><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">Source management</div><h2 className="mt-2 font-display text-xl font-bold">Recent catalog cuts</h2></div><span className="rounded-lg bg-secondary-foreground/10 px-2 py-1 font-mono-ui text-[9px] text-secondary-foreground/60">{scenes.data?.length ?? 0} LOADED</span></div>{scenes.isLoading ? <div className="space-y-2"><div className="skeleton h-16 rounded-xl" /><div className="skeleton h-16 rounded-xl" /></div> : scenes.isError ? <p className="rounded-xl bg-accent/10 p-4 text-xs text-secondary-foreground/70">The protected source list could not be loaded.</p> : <div className="space-y-2">{scenes.data?.map((scene) => <div key={scene.id} className="flex items-center gap-3 rounded-xl bg-secondary-foreground/5 p-2.5" data-testid={`row-admin-scene-${scene.id}`}><ImageWithFallback src={scene.thumbnailUrl} alt={scene.title} className="size-12 shrink-0 rounded-lg" /><div className="min-w-0 flex-1"><div className="truncate text-xs font-bold">{scene.title}</div><div className="truncate text-[10px] text-secondary-foreground/55">{scene.animeTitle} / {scene.sourceName}</div></div><button type="button" onClick={() => updateScene.mutate({ sceneId: scene.id, data: scenePayload(scene, !scene.isFeatured) }, { onSuccess: () => { refreshScenes(); announce(scene.isFeatured ? 'Scene unfeatured.' : 'Scene featured.'); } })} data-testid={`button-toggle-featured-${scene.id}`} className={`rounded-lg px-2 py-1.5 font-mono-ui text-[9px] ${scene.isFeatured ? 'bg-primary text-primary-foreground' : 'bg-secondary-foreground/10 text-secondary-foreground/70'}`}>{scene.isFeatured ? 'FEATURED' : 'FEATURE'}</button><button type="button" onClick={() => { if (window.confirm(`Remove “${scene.title}” from the catalog?`)) deleteScene.mutate({ sceneId: scene.id }, { onSuccess: () => { refreshScenes(); announce('Scene removed from the index.'); } }); }} data-testid={`button-remove-admin-scene-${scene.id}`} className="rounded-lg px-2 py-1.5 font-mono-ui text-[9px] text-accent hover:bg-accent/10">REMOVE</button></div>)}</div>}</section></div><div className="mt-6 grid gap-4 lg:grid-cols-3"><AdminMetaCard kind="anime" /><AdminMetaCard kind="character" /><AdminMetaCard kind="category" /></div><section className="mt-6 rounded-2xl border border-border bg-card p-5"><div className="mb-4 flex items-center justify-between"><div><div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">Source reports</div><h2 className="mt-2 font-display text-xl font-bold">Review queue</h2></div><span className="font-mono-ui text-[10px] text-muted-foreground">{reports.data?.filter((report) => report.status === 'open').length ?? 0} OPEN</span></div>{reports.isLoading ? <div className="skeleton h-14 rounded-xl" /> : reports.isError ? <p className="text-sm text-muted-foreground">Reports are not available right now.</p> : reports.data?.length ? <div className="divide-y divide-border">{reports.data.map((report) => <div key={report.id} className="flex flex-wrap items-center gap-3 py-3" data-testid={`row-admin-report-${report.id}`}><span className="rounded bg-accent/10 px-2 py-1 font-mono-ui text-[9px] text-accent">SCENE {report.sceneId}</span><span className="min-w-40 flex-1 text-sm">{report.reason}</span><span className="font-mono-ui text-[9px] text-muted-foreground">{report.status.toUpperCase()}</span>{report.status === 'open' && <div className="flex gap-2"><button type="button" onClick={() => updateReport.mutate({ reportId: report.id, data: { status: 'reviewed' } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListAdminReportsQueryKey() }); announce('Report marked reviewed.'); } })} data-testid={`button-review-report-${report.id}`} className="rounded-lg border border-border px-2.5 py-1.5 text-[10px] font-bold hover:border-primary hover:text-primary">Mark reviewed</button><button type="button" onClick={() => updateReport.mutate({ reportId: report.id, data: { status: 'dismissed' } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListAdminReportsQueryKey() }); announce('Report dismissed.'); } })} data-testid={`button-dismiss-report-${report.id}`} className="rounded-lg border border-border px-2.5 py-1.5 text-[10px] font-bold hover:border-accent hover:text-accent">Dismiss</button></div>}</div>)}</div> : <p className="text-sm text-muted-foreground">No source reports. The queue is clear.</p>}</section><ToastNotice message={notice} /></PageFrame>;
}

function InfoPage({ type }: { type: 'about' | 'faq' | 'help' | 'privacy' | 'terms' }) {
  const content = { about: ['The scene you can almost remember.', 'Stxclips is a visual search desk for anime editors. It is built around a simple gap in the workflow: you know the exact emotional temperature of a scene, but not the episode, source, or title.'], faq: ['Questions, before the cut.', 'Search by the words you remember, the character who was there, or the energy of the scene. Stxclips gets more useful when your memory is incomplete.'], help: ['Make the archive work for you.', 'Start broad. Search “train station goodbye” before “episode 12”. Save the searches that repeat. Open a scene to trace it back to the original source.'], privacy: ['Privacy, without the fine print fog.', 'Your saved searches, favorites, and history stay attached to your account so your desk feels personal. We do not sell your creative work or your search history.'], terms: ['The practical terms.', 'Stxclips is a discovery index. Sources remain owned by their respective publishers. Use footage responsibly, respect local law, and credit the original source when your project calls for it.'] }[type]; return <PageFrame><div className="mx-auto max-w-3xl py-8 sm:py-16"><div className="mb-5 font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Stxclips / {type}</div><h1 className="font-display text-5xl font-bold tracking-[-.07em] sm:text-7xl">{content[0]}</h1><p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground">{content[1]}</p><div className="mt-14 space-y-8 border-t border-border pt-8 text-sm leading-7 text-muted-foreground"><p>We design for the moment between remembering and finding. The interface stays quiet, the index stays quick, and the useful detail is always one click away.</p><p>Need a hand? <Link href="/help" data-testid="link-info-help" className="font-bold text-primary hover:underline">Read the field guide</Link> or return to <Link href="/" data-testid="link-info-home" className="font-bold text-primary hover:underline">the discovery desk</Link>.</p></div></div></PageFrame>;
}

export { HomePage, SearchPage, BrowsePage, FavoritesPage, DashboardPage, AdminPage, InfoPage };