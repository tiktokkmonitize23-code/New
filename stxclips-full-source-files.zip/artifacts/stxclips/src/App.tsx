import { useEffect, useRef } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { Shell } from '@/components/stxclips';
import { HomePage, SearchPage, BrowsePage, FavoritesPage, DashboardPage, AdminPage, InfoPage } from '@/pages/stxclips-pages';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#087d7e',
    colorForeground: '#172038',
    colorMutedForeground: '#657080',
    colorDanger: '#c94a3c',
    colorBackground: '#f7f3e9',
    colorInput: '#f1ece2',
    colorInputForeground: '#172038',
    colorNeutral: '#d7d0c4',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#f7f3e9] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'font-display text-[#172038]',
    headerSubtitle: 'text-[#657080]',
    socialButtonsBlockButtonText: 'text-[#172038]',
    formFieldLabel: 'text-[#172038]',
    footerActionLink: 'text-[#087d7e]',
    footerActionText: 'text-[#657080]',
    dividerText: 'text-[#657080]',
    formButtonPrimary: 'bg-[#087d7e] hover:bg-[#06686a]',
    formFieldInput: 'bg-[#f1ece2] text-[#172038] border-[#d7d0c4]',
    footerAction: 'text-[#657080]',
    dividerLine: 'bg-[#d7d0c4]',
    alert: 'bg-[#fbe8df]',
    alertText: 'text-[#172038]',
    otpCodeFieldInput: 'bg-[#f1ece2] text-[#172038]',
    formFieldRow: 'text-[#172038]',
    main: 'bg-transparent',
  },
};

function AuthPage({ kind }: { kind: 'sign-in' | 'sign-up' }) {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-secondary px-4 py-10"><div className="absolute left-6 top-6"><a href={basePath || '/'} className="font-display text-xl font-bold text-secondary-foreground">stx<span className="text-primary">clips</span></a></div>{kind === 'sign-in' ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />}</div>;
}

function CacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previous = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (previous.current !== undefined && previous.current !== id) client.clear();
      previous.current = id;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><Shell><HomePage /></Shell></Show></>;
}

function ProtectedPage({ children }: { children: React.ReactNode }) {
  return <Shell>{children}</Shell>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/sign-in/*?" component={() => <AuthPage kind="sign-in" />} />
    <Route path="/sign-up/*?" component={() => <AuthPage kind="sign-up" />} />
    <Route path="/search" component={() => <ProtectedPage><SearchPage /></ProtectedPage>} />
    <Route path="/anime" component={() => <ProtectedPage><BrowsePage type="anime" /></ProtectedPage>} />
    <Route path="/characters" component={() => <ProtectedPage><BrowsePage type="characters" /></ProtectedPage>} />
    <Route path="/categories" component={() => <ProtectedPage><BrowsePage type="categories" /></ProtectedPage>} />
    <Route path="/favorites" component={() => <ProtectedPage><FavoritesPage /></ProtectedPage>} />
    <Route path="/dashboard" component={() => <ProtectedPage><DashboardPage /></ProtectedPage>} />
    <Route path="/admin" component={() => <ProtectedPage><AdminPage /></ProtectedPage>} />
    <Route path="/about" component={() => <ProtectedPage><InfoPage type="about" /></ProtectedPage>} />
    <Route path="/faq" component={() => <ProtectedPage><InfoPage type="faq" /></ProtectedPage>} />
    <Route path="/help" component={() => <ProtectedPage><InfoPage type="help" /></ProtectedPage>} />
    <Route path="/privacy" component={() => <ProtectedPage><InfoPage type="privacy" /></ProtectedPage>} />
    <Route path="/terms" component={() => <ProtectedPage><InfoPage type="terms" /></ProtectedPage>} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Your next cut is waiting.' } }, signUp: { start: { title: 'Make a place for your cuts', subtitle: 'Build your personal scene index.' } } }} routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}><QueryClientProvider client={queryClient}><CacheInvalidator /><Router /><Toaster /></QueryClientProvider></ClerkProvider>;
}

function App() {
  return <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>;
}

export default App;