import type { NextFunction, Request, Response } from "express";
import { getAuth } from "@clerk/express";
import { db, profileTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export type AuthenticatedRequest = Request & {
  userId?: string;
};

export function getUserId(req: Request): string | null {
  const auth = getAuth(req);
  return auth?.userId ?? null;
}

export async function ensureProfile(userId: string) {
  const existing = await db
    .select()
    .from(profileTable)
    .where(eq(profileTable.id, userId))
    .limit(1);

  if (existing[0]) return existing[0];

  const [profile] = await db
    .insert(profileTable)
    .values({
      id: userId,
      username: `editor-${userId.slice(-6)}`,
      email: "Signed-in editor",
      imageUrl: "",
      role: "editor",
    })
    .onConflictDoNothing()
    .returning();

  return profile ?? (await db.select().from(profileTable).where(eq(profileTable.id, userId)).limit(1))[0];
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  req.userId = userId;
  next();
}

export async function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const adminIds = (process.env.ADMIN_USER_IDS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);
  const profile = await ensureProfile(userId);
  if (profile?.role !== "admin" && !adminIds.includes(userId)) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  req.userId = userId;
  next();
}