import { Router, type IRouter } from "express";
import { and, asc, count, desc, eq, gte, ilike, lte, or } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  animeTable,
  characterTable,
  favoriteTable,
  historyTable,
  profileTable,
  reportTable,
  savedSearchTable,
  sceneCategoryTable,
  sceneTable,
} from "@workspace/db";
import {
  AddFavoriteParams,
  CreateSavedSearchBody,
  CreateSavedSearchResponse,
  DeleteSavedSearchParams,
  GetAdminSummaryResponse,
  GetHomeResponse,
  GetMeResponse,
  GetSceneParams,
  GetSceneResponse,
  CreateAdminSceneBody,
  CreateAdminSceneResponse,
  UpdateAdminSceneParams,
  UpdateAdminSceneBody,
  UpdateAdminSceneResponse,
  DeleteAdminSceneParams,
  CreateAdminAnimeBody,
  CreateAdminAnimeResponse,
  UpdateAdminAnimeParams,
  UpdateAdminAnimeBody,
  UpdateAdminAnimeResponse,
  CreateAdminCharacterBody,
  CreateAdminCharacterResponse,
  UpdateAdminCharacterParams,
  UpdateAdminCharacterBody,
  UpdateAdminCharacterResponse,
  CreateAdminCategoryBody,
  CreateAdminCategoryResponse,
  UpdateAdminCategoryParams,
  UpdateAdminCategoryBody,
  UpdateAdminCategoryResponse,
  ListAdminScenesResponse,
  ListAdminReportsResponse,
  UpdateAdminReportParams,
  UpdateAdminReportBody,
  UpdateAdminReportResponse,
  ListAnimeResponse,
  ListCategoriesResponse,
  ListCharactersResponse,
  ListFavoritesResponse,
  ListHistoryResponse,
  ListRecentSourcesResponse,
  ListSavedSearchesResponse,
  ListScenesQueryParams,
  ListScenesResponse,
  ListTrendingResponse,
  RecordHistoryBody,
} from "@workspace/api-zod";
import { getUserId, ensureProfile, requireAdmin, requireAuth, type AuthenticatedRequest } from "../middlewares/auth";

const router: IRouter = Router();

const seededTrending = [
  { term: "domain expansion", count: 482, trend: "up" as const },
  { term: "rage transformation", count: 361, trend: "up" as const },
  { term: "quiet character moments", count: 247, trend: "new" as const },
  { term: "villain entrance", count: 194, trend: "steady" as const },
];

function sceneResponse(scene: typeof sceneTable.$inferSelect) {
  return {
    ...scene,
    addedAt: scene.addedAt.toISOString(),
    tags: scene.tags ?? [],
  };
}

function queryParams(req: AuthenticatedRequest) {
  const parsed = ListScenesQueryParams.safeParse(req.query);
  return parsed.success ? parsed.data : null;
}

async function loadScenes(params: ReturnType<typeof queryParams>) {
  const page = params?.page ?? 1;
  const pageSize = params?.pageSize ?? 12;
  const q = params?.q?.trim();
  const filters = [
    q
      ? or(
          ilike(sceneTable.title, `%${q}%`),
          ilike(sceneTable.animeTitle, `%${q}%`),
          ilike(sceneTable.character, `%${q}%`),
          ilike(sceneTable.description, `%${q}%`),
          ilike(sceneTable.category, `%${q}%`),
        )
      : undefined,
    params?.anime ? ilike(sceneTable.animeTitle, `%${params.anime.replaceAll("-", " ")}%`) : undefined,
    params?.character ? ilike(sceneTable.character, `%${params.character}%`) : undefined,
    params?.category ? ilike(sceneTable.category, `%${params.category.replaceAll("-", " ")}%`) : undefined,
    params?.episode ? eq(sceneTable.episode, params.episode) : undefined,
    params?.durationMin ? gte(sceneTable.durationSeconds, params.durationMin) : undefined,
    params?.durationMax ? lte(sceneTable.durationSeconds, params.durationMax) : undefined,
  ].filter(Boolean);

  const where = filters.length ? and(...filters) : undefined;
  const [rows, totalRows] = await Promise.all([
    db
      .select()
      .from(sceneTable)
      .where(where)
      .orderBy(desc(sceneTable.isFeatured), desc(sceneTable.addedAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db.select({ value: count() }).from(sceneTable).where(where),
  ]);

  return {
    items: rows.map(sceneResponse),
    total: Number(totalRows[0]?.value ?? 0),
    page,
    pageSize,
    query: q ?? "",
  };
}

router.get("/home", async (_req, res): Promise<void> => {
  const [featuredScenes, popularAnime, popularCharacters, categories, recentSources] = await Promise.all([
    db.select().from(sceneTable).orderBy(desc(sceneTable.isFeatured), desc(sceneTable.addedAt)).limit(6),
    db.select().from(animeTable).orderBy(desc(animeTable.sceneCount), asc(animeTable.title)).limit(6),
    db.select().from(characterTable).orderBy(desc(characterTable.sceneCount), asc(characterTable.name)).limit(6),
    db.select().from(sceneCategoryTable).orderBy(desc(sceneCategoryTable.sceneCount), asc(sceneCategoryTable.name)).limit(6),
    db.select().from(sceneTable).orderBy(desc(sceneTable.addedAt)).limit(4),
  ]);
  res.json(GetHomeResponse.parse({
    featuredScenes: featuredScenes.map(sceneResponse),
    popularAnime,
    popularCharacters,
    categories,
    trending: seededTrending,
    recentSources: recentSources.map(sceneResponse),
  }));
});

router.get("/scenes", async (req, res): Promise<void> => {
  const params = queryParams(req);
  if (!params) {
    res.status(400).json({ error: "Invalid search filters" });
    return;
  }
  res.json(ListScenesResponse.parse(await loadScenes(params)));
});

router.get("/scenes/:sceneId", async (req, res): Promise<void> => {
  const parsed = GetSceneParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [scene] = await db.select().from(sceneTable).where(eq(sceneTable.id, parsed.data.sceneId)).limit(1);
  if (!scene) {
    res.status(404).json({ error: "Scene not found" });
    return;
  }
  res.json(GetSceneResponse.parse(sceneResponse(scene)));
});

router.get("/anime", async (_req, res): Promise<void> => {
  const rows = await db.select().from(animeTable).orderBy(desc(animeTable.sceneCount), asc(animeTable.title));
  res.json(ListAnimeResponse.parse(rows));
});

router.get("/characters", async (_req, res): Promise<void> => {
  const rows = await db.select().from(characterTable).orderBy(desc(characterTable.sceneCount), asc(characterTable.name));
  res.json(ListCharactersResponse.parse(rows));
});

router.get("/categories", async (_req, res): Promise<void> => {
  const rows = await db.select().from(sceneCategoryTable).orderBy(desc(sceneCategoryTable.sceneCount), asc(sceneCategoryTable.name));
  res.json(ListCategoriesResponse.parse(rows));
});

router.get("/trending", (_req, res): void => {
  res.json(ListTrendingResponse.parse(seededTrending));
});

router.get("/sources/recent", async (_req, res): Promise<void> => {
  const rows = await db.select().from(sceneTable).orderBy(desc(sceneTable.addedAt)).limit(12);
  res.json(ListRecentSourcesResponse.parse(rows.map(sceneResponse)));
});

router.get("/me", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const profile = await ensureProfile(req.userId!);
  const [favoriteCount, savedSearchCount, historyCount] = await Promise.all([
    db.select({ value: count() }).from(favoriteTable).where(eq(favoriteTable.userId, profile.id)),
    db.select({ value: count() }).from(savedSearchTable).where(eq(savedSearchTable.userId, profile.id)),
    db.select({ value: count() }).from(historyTable).where(eq(historyTable.userId, profile.id)),
  ]);
  res.json(GetMeResponse.parse({
    id: profile.id,
    username: profile.username,
    email: profile.email,
    imageUrl: profile.imageUrl,
    role: profile.role === "admin" ? "admin" : "editor",
    favoriteCount: Number(favoriteCount[0]?.value ?? 0),
    savedSearchCount: Number(savedSearchCount[0]?.value ?? 0),
    historyCount: Number(historyCount[0]?.value ?? 0),
  }));
});

router.get("/me/favorites", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const rows = await db
    .select({ scene: sceneTable })
    .from(favoriteTable)
    .innerJoin(sceneTable, eq(sceneTable.id, favoriteTable.sceneId))
    .where(eq(favoriteTable.userId, req.userId!))
    .orderBy(desc(favoriteTable.createdAt));
  res.json(ListFavoritesResponse.parse(rows.map(({ scene }) => sceneResponse(scene))));
});

router.post("/me/favorites/:sceneId", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = AddFavoriteParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await db.insert(favoriteTable).values({ userId: req.userId!, sceneId: parsed.data.sceneId }).onConflictDoNothing();
  res.sendStatus(204);
});

router.delete("/me/favorites/:sceneId", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = AddFavoriteParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await db.delete(favoriteTable).where(and(eq(favoriteTable.userId, req.userId!), eq(favoriteTable.sceneId, parsed.data.sceneId)));
  res.sendStatus(204);
});

router.get("/me/saved-searches", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const rows = await db.select().from(savedSearchTable).where(eq(savedSearchTable.userId, req.userId!)).orderBy(desc(savedSearchTable.createdAt));
  res.json(ListSavedSearchesResponse.parse(rows.map(({ id, name, query, createdAt }) => ({ id, name, query, createdAt: createdAt.toISOString() }))));
});

router.post("/me/saved-searches", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = CreateSavedSearchBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [saved] = await db.insert(savedSearchTable).values({ userId: req.userId!, ...parsed.data }).returning();
  res.status(201).json(CreateSavedSearchResponse.parse({ ...saved, createdAt: saved.createdAt.toISOString() }));
});

router.delete("/me/saved-searches/:searchId", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = DeleteSavedSearchParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await db.delete(savedSearchTable).where(and(eq(savedSearchTable.id, parsed.data.searchId), eq(savedSearchTable.userId, req.userId!)));
  res.sendStatus(204);
});

router.get("/me/history", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const rows = await db
    .select({ scene: sceneTable })
    .from(historyTable)
    .innerJoin(sceneTable, eq(sceneTable.id, historyTable.sceneId))
    .where(eq(historyTable.userId, req.userId!))
    .orderBy(desc(historyTable.viewedAt))
    .limit(24);
  res.json(ListHistoryResponse.parse(rows.map(({ scene }) => sceneResponse(scene))));
});

router.post("/me/history", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = RecordHistoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await db
    .insert(historyTable)
    .values({ userId: req.userId!, sceneId: parsed.data.sceneId })
    .onConflictDoUpdate({ target: [historyTable.userId, historyTable.sceneId], set: { viewedAt: new Date() } });
  res.sendStatus(204);
});

router.get("/admin/summary", requireAdmin, async (_req, res): Promise<void> => {
  const [[sceneCount], [animeCount], [characterCount], [categoryCount], [flaggedSourceCount]] = await Promise.all([
    db.select({ value: count() }).from(sceneTable),
    db.select({ value: count() }).from(animeTable),
    db.select({ value: count() }).from(characterTable),
    db.select({ value: count() }).from(sceneCategoryTable),
    db.select({ value: count() }).from(reportTable).where(eq(reportTable.status, "open")),
  ]);
  res.json(GetAdminSummaryResponse.parse({
    sceneCount: Number(sceneCount?.value ?? 0),
    animeCount: Number(animeCount?.value ?? 0),
    characterCount: Number(characterCount?.value ?? 0),
    categoryCount: Number(categoryCount?.value ?? 0),
    flaggedSourceCount: Number(flaggedSourceCount?.value ?? 0),
  }));
});

router.get("/admin/scenes", requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(sceneTable).orderBy(desc(sceneTable.addedAt)).limit(60);
  res.json(ListAdminScenesResponse.parse(rows.map(sceneResponse)));
});

router.post("/admin/scenes", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateAdminSceneBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [scene] = await db.insert(sceneTable).values(parsed.data).returning();
  res.status(201).json(CreateAdminSceneResponse.parse(sceneResponse(scene)));
});

router.patch("/admin/scenes/:sceneId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminSceneParams.safeParse(req.params);
  const body = UpdateAdminSceneBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid scene update" });
    return;
  }
  const [scene] = await db.update(sceneTable).set(body.data).where(eq(sceneTable.id, params.data.sceneId)).returning();
  if (!scene) {
    res.status(404).json({ error: "Scene not found" });
    return;
  }
  res.json(UpdateAdminSceneResponse.parse(sceneResponse(scene)));
});

router.delete("/admin/scenes/:sceneId", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteAdminSceneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db.delete(sceneTable).where(eq(sceneTable.id, params.data.sceneId));
  res.sendStatus(204);
});

router.post("/admin/anime", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateAdminAnimeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [anime] = await db.insert(animeTable).values(parsed.data).returning();
  res.status(201).json(CreateAdminAnimeResponse.parse(anime));
});

router.patch("/admin/anime/:animeId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminAnimeParams.safeParse(req.params);
  const body = UpdateAdminAnimeBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid anime update" });
    return;
  }
  const [anime] = await db.update(animeTable).set(body.data).where(eq(animeTable.id, params.data.animeId)).returning();
  if (!anime) {
    res.status(404).json({ error: "Anime not found" });
    return;
  }
  res.json(UpdateAdminAnimeResponse.parse(anime));
});

router.post("/admin/characters", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateAdminCharacterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [character] = await db.insert(characterTable).values(parsed.data).returning();
  res.status(201).json(CreateAdminCharacterResponse.parse(character));
});

router.patch("/admin/characters/:characterId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminCharacterParams.safeParse(req.params);
  const body = UpdateAdminCharacterBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid character update" });
    return;
  }
  const [character] = await db.update(characterTable).set(body.data).where(eq(characterTable.id, params.data.characterId)).returning();
  if (!character) {
    res.status(404).json({ error: "Character not found" });
    return;
  }
  res.json(UpdateAdminCharacterResponse.parse(character));
});

router.post("/admin/categories", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateAdminCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [category] = await db.insert(sceneCategoryTable).values(parsed.data).returning();
  res.status(201).json(CreateAdminCategoryResponse.parse(category));
});

router.patch("/admin/categories/:categoryId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminCategoryParams.safeParse(req.params);
  const body = UpdateAdminCategoryBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid category update" });
    return;
  }
  const [category] = await db.update(sceneCategoryTable).set(body.data).where(eq(sceneCategoryTable.id, params.data.categoryId)).returning();
  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }
  res.json(UpdateAdminCategoryResponse.parse(category));
});

router.get("/admin/reports", requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(reportTable).orderBy(desc(reportTable.createdAt)).limit(60);
  res.json(ListAdminReportsResponse.parse(rows.map((report) => ({ ...report, createdAt: report.createdAt.toISOString() }))));
});

router.patch("/admin/reports/:reportId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminReportParams.safeParse(req.params);
  const body = UpdateAdminReportBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid report update" });
    return;
  }
  const [report] = await db.update(reportTable).set(body.data).where(eq(reportTable.id, params.data.reportId)).returning();
  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }
  res.json(UpdateAdminReportResponse.parse({ ...report, createdAt: report.createdAt.toISOString() }));
});

export default router;