import { Router, type IRouter } from "express";
import healthRouter from "./health";
import stxclipsRouter from "./stxclips";

const router: IRouter = Router();

router.use(healthRouter);
router.use(stxclipsRouter);

export default router;
