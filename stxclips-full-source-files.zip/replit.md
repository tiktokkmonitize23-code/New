# Stxclips

Stxclips is a visual search desk for anime editors: it indexes scene metadata and links editors back to legitimate source pages without hosting copyrighted footage.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required auth env: `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`, `VITE_CLERK_PUBLISHABLE_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/stxclips` — React/Vite web app and visual design
- `artifacts/api-server` — Express API, Clerk middleware, seed data, and protected admin routes
- `lib/db/src/schema/stxclips.ts` — Drizzle schema for the Stxclips catalog and user workspace
- `lib/api-spec/openapi.yaml` — API source of truth; regenerate clients with the codegen command above
- `STXCLIPS_DEPLOYMENT.md` — deployment and InfinityFree compatibility notes

## Architecture decisions

- Scene records contain metadata and source links only; the app does not download or re-host anime footage.
- Clerk supplies secure browser authentication; server-side admin access is checked against the Clerk user metadata role.
- PostgreSQL stores catalog and account-linked workspace data; API clients and Zod validators are generated from OpenAPI.
- The web app can be built as a static Vite bundle, but authenticated functionality requires the Express API, PostgreSQL, and Clerk configuration.

## Product

Users can search and filter scenes, browse anime/characters/categories, open source links, save favorites, store saved searches, review history, and access protected admin catalog controls.

## User preferences

- The requested delivery format is a ZIP suitable for upload workflows, with deployment limitations documented instead of hidden.

## Gotchas

- InfinityFree file manager can serve the generated frontend but cannot run this Node/Express API or PostgreSQL-backed Clerk session flow.
- For a full deployment, use a Node-capable host and external PostgreSQL/Clerk configuration; upload `artifacts/stxclips/dist/public` only for a static shell.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
