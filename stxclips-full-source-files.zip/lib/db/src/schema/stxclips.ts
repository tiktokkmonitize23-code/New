import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const animeTable = pgTable("anime", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  year: integer("year").notNull(),
  genre: text("genre").notNull(),
  accent: text("accent").notNull().default("#d71942"),
  imageUrl: text("image_url").notNull(),
  sceneCount: integer("scene_count").notNull().default(0),
});

export const characterTable = pgTable("characters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  animeTitle: text("anime_title").notNull(),
  role: text("role").notNull(),
  imageUrl: text("image_url").notNull(),
  sceneCount: integer("scene_count").notNull().default(0),
});

export const sceneCategoryTable = pgTable("scene_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sceneCount: integer("scene_count").notNull().default(0),
  description: text("description").notNull(),
});

export const sceneTable = pgTable("scenes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  animeTitle: text("anime_title").notNull(),
  animeSlug: text("anime_slug").notNull(),
  character: text("character").notNull(),
  episode: integer("episode").notNull(),
  description: text("description").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  sourceName: text("source_name").notNull(),
  sourceUrl: text("source_url").notNull(),
  tags: text("tags").array().notNull().default([]),
  category: text("category").notNull(),
  isFeatured: boolean("is_featured").notNull().default(false),
  addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
});

export const profileTable = pgTable("profiles", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  imageUrl: text("image_url").notNull().default(""),
  role: text("role").notNull().default("editor"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const favoriteTable = pgTable(
  "favorites",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    sceneId: integer("scene_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [unique("favorites_user_scene_unique").on(table.userId, table.sceneId)],
);

export const savedSearchTable = pgTable("saved_searches", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  query: text("query").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const historyTable = pgTable(
  "scene_history",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    sceneId: integer("scene_id").notNull(),
    viewedAt: timestamp("viewed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [unique("history_user_scene_unique").on(table.userId, table.sceneId)],
);

export const reportTable = pgTable("source_reports", {
  id: serial("id").primaryKey(),
  sceneId: integer("scene_id").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAnimeSchema = createInsertSchema(animeTable).omit({ id: true });
export const insertCharacterSchema = createInsertSchema(characterTable).omit({ id: true });
export const insertSceneCategorySchema = createInsertSchema(sceneCategoryTable).omit({ id: true });
export const insertSceneSchema = createInsertSchema(sceneTable).omit({ id: true, addedAt: true });
export type InsertAnime = z.infer<typeof insertAnimeSchema>;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;
export type InsertSceneCategory = z.infer<typeof insertSceneCategorySchema>;
export type InsertScene = z.infer<typeof insertSceneSchema>;
export type Anime = typeof animeTable.$inferSelect;
export type Character = typeof characterTable.$inferSelect;
export type SceneCategory = typeof sceneCategoryTable.$inferSelect;
export type Scene = typeof sceneTable.$inferSelect;