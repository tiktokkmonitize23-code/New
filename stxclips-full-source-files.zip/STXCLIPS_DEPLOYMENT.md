# Stxclips deployment guide

## What is included

The full source bundle includes:

- React/Vite frontend in `artifacts/stxclips`
- Express API in `artifacts/api-server`
- PostgreSQL/Drizzle schema and seed data in `lib/db`
- OpenAPI contract and generated clients in `lib/api-spec`, `lib/api-client-react`, and `lib/api-zod`
- Clerk authentication and protected admin routes

Stxclips stores scene metadata and links to legitimate source pages. It does not download, copy, or re-host anime footage.

## Important InfinityFree limitation

InfinityFree File Manager is suitable for static files and PHP hosting. The complete Stxclips app is not an InfinityFree-only application because it requires:

1. A Node.js process running the Express API.
2. PostgreSQL for the catalog and account workspace.
3. Clerk configuration for browser authentication.

Uploading the full source ZIP to `htdocs` will not start the API. Uploading only the static bundle will show the frontend shell, but search data, authentication, favorites, saved searches, history, and admin actions require a reachable API.

For a complete working deployment, use a Node-capable host for the API and a managed PostgreSQL database. The frontend can be hosted separately if the API URL and CORS policy are configured for that domain.

## Build locally

From the repository root:

```bash
pnpm install
pnpm run typecheck
pnpm --filter @workspace/stxclips run build
pnpm --filter @workspace/api-server run build
```

The static frontend output is:

```text
artifacts/stxclips/dist/public
```

## Environment

The API needs:

- `DATABASE_URL`
- `CLERK_SECRET_KEY`
- `CLERK_PUBLISHABLE_KEY`
- `VITE_CLERK_PUBLISHABLE_KEY`
- `PORT` (the API defaults to the host-provided port)

Do not put server secrets in the frontend ZIP or commit them to the repository.

## InfinityFree static upload

If you only want to inspect the visual frontend:

1. Upload the contents of `static-frontend/` to `htdocs`.
2. Keep the included `index.html`, assets, `logo.svg`, `favicon.svg`, and `robots.txt` together.
3. This is a static preview, not the complete application. API-backed features will not work until the frontend is rebuilt against a reachable API.

The ZIP named `stxclips-infinityfree-static.zip` contains this static preview. The ZIP named `stxclips-full-stack.zip` contains the complete source deployment bundle.